# **Handling Overfitting in a Constrained 6-Layer CNN Model**



## This document summarizes the systematic steps taken to diagnose and mitigate overfitting in a convolutional neural network(CNN) trained on 28 x 28 grayscale images.



### **1.	Initial Problem**



* The original model showed clear signs of overfitting:
* Training accuracy increased rapidly.
* Validation accuracy plateaued and began to decline.
* Validation loss increased while training loss continued to decrease.

This indicated that the model was memorizing the training data rather than learning generalizable patterns.



### **2.	First Mitigation: Reducing Epochs**



We reduced the number of training epochs from 10 to 5. 



#### Rationale:

* Overfitting began early (around epoch 3).
* Shorter training prevents the model from drifting into memorization.



##### Outcome

* Overfitting was reduced but still present.





### 3\.	Second Mitigation: Reducing Model Capacity

Because the project constraints limited the model to exactly 6 layers, we could not remove convolutional blocks. Instead, we reduced the size of existing layers:

#### A.	Reduced convolutional filters:

* Early convolutional filters were reduced from 32 to 26.
* This lowered the representational capacity of the model.



#### B.	Reduced dense layer size:

* Dense layer reduced from 128 units to 64 units.
* This further reduced the model’s ability to memorize training data.



##### Outcome:



* The model became smaller and more efficient.
* Overfitting was reduced but not eliminated.



### 4\.	Final Mitigation: Introducing Data Augmentation



Since architectural reduction and epoch limits were insufficient, we introduced data augmentation to artificially expand the training dataset.

### Augmentation techniques used:

* Random rotation
* Random translation
* Random zoom



##### Rationale:



* Augmentation increases data diversity.
* It forces the model to learn more robust features.
* It reduces the gap between training and validation performance.



##### Outcome:

* Validation accuracy improved.
* Validation loss decreased.
* Training and validation curves aligned more closely
* Overfitting was effectively controlled.



### 5\.	Final  Result



##### After applying augmentation, the model demonstrated.



* Improved generalization.
* Stable validation accuracy.
* Reduced divergence between training and validation loss.



This confirms that data augmentation was the most effective strategy for mitigating overfitting under the given architectural constraints.

We essentially transformed the model from:

Overfitting  --  Balanced --  Generalizing

Emphasize the progression you want and expect in a controlled experiment.





