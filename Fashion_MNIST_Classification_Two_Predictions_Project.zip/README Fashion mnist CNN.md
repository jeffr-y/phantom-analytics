# **Fashion MNIST Convolutional Neural Network Classification (CNN)**

## Fully Automated Implementation in Python and R

### Project Overview



This project implements a 6-layer Convolutional Neural Network (CNN) to classify the Fashion MNIST dataset.

Two complete, production-ready implementations are provided:



##### **Python (TensorFlow/Keras)**

##### **R (Keras + TensorFlow via reticulate)**



##### Both versions:



* Train a CNN model
* Generate predictions
* Compute evaluation metrics
* Create a confusion matrix (10 x10 wide format)
* Save all outputs into 
* 
* A single Excel workbook
* PNG figures
* A combined PDF report
* Automatically create an output folder if it does not exist



All Blocks run in one execution.



### Python Implementation



##### Output Folder 



fashion\_mnist\_classification\_python/

Content

* Fashion\_mnist\_all\_outputs.xlsx
* Training\_History
* Predictions
* Confusion\_Matrix (10 x10 wide)
* Metrics (Accuracy + Macro F1)
* raining\_history.png
* predicted\_images.png
* fashion\_mnist\_figures.pdf



##### Requirements (Python)



1. Python 3.10 and above
2. TensorFlow 2.x
3. NumPy
4. Pandas
5. Matplotlib
6. Scikit-learn
7. OpenPyXL



##### Install:

* Conda  install -c conda-forge tensorflow numpy pandas matplotlib scikit-learn openpyxl



##### How to Run (Python)

* Fashion\_MNIST\_Classification\_Project\_Python.ipynb



All outputs will be generated automatically inside:

* fashion\_mnist\_classification\_python



with a confirmatory successful message  as output



### R Implementation

##### 

##### Output Folder

•	fashion\_mnist\_classification\_project\_r /



Content:



fashion\_mnist\_all\_r\_outputs.xlsx



a.	Training\_History

b.	Predictions

c.	Confusion\_Matrix (10x10 matrix form)

d.	Metrics

e.	Training\_history.png

f.	predict\_images.png

g.	fashion\_mnist\_figures,pdf



##### Requirements (R)

•	R  Version 4.2 and above

•	Python 3.10(Conda recommended)

•	TensorFlow 2.x

•	Required R Packages:

•	Keras

•	Tensorflow

•	Reticulate

•	dplyr

•	tidyr

•	yardstick

•	openxlsx



##### install in R:

install.packages(c(“keras”,”tensorflow”,”reticulate”,”dplyr”,”tidyr”,”yardstick”,”openxlsx”)). This can be done on R.ipynb



##### How to Run R

•	Source(Fashion\_MNIST\_Classification\_Project\_R.ipynb)



All outputs are generated automatically inside:



•	fashion\_mnist\_classification\_project\_r/ 



### CNN Architecture (Both implementations)

##### 

##### The model contains 6 layers:



•	1 Conv2D (32 filters, ReLU)

•	2 Conv2D (64 filters, ReLU)

•	3 MaxPooling @D

•	4 Flatten

•	5 Dense (128 units, ReLU)

•	6 Dense(10 units, Softmax



##### Loss Function:



•	sparse\_categorical\_crossentropy



Optimizer:



•	Adam



##### Evaluation Outputs

Each implementation computes:

•	Test Accuracy

•	Macro FI Score

•	10x10 Confusion Matrix (Wide format)

•	Predictions dataset

•	Training history (loss+accuracy)

•	Confusion matrix is saved in Excel as:

&nbsp;			Pred\_0 Pred\_1.....Pred\_9

&nbsp;	Actual\_0

&nbsp;			Pred\_0 Pred\_1.....Pred\_9

&nbsp;	Actual\_1

&nbsp;	....

&nbsp;	Actual\_9



##### Figures Generated



###### Both Implementations save:



•	1 Training vs Validation Accuracy

•	2 Training vs Validation Loss

•	First 2 Test Image Predictions

•	Combined PDF containing all figures



###### Key Features



•	Fully automated execution

•	Folder auto-creation

•	Clean confusion matrix (no missing levels)

•	Single Excel workbook per implementation

•	Reproducible workflow

•	Submission-ready output

•	Portfolio Value

•	This project demonstrates:

•	Deep Learning (NN)

•	Model evaluation best practices

•	Cross-language implementation (Python + R

•	Reproducible ML workflows

•	Automated reporting pipelines

•	Clean experiment organizations









