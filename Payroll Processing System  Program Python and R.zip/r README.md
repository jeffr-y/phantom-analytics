# Payroll Processing Program (R)



## Overview



This program implements a Payroll simulation in R for 500 employees. It mirrors the Python version's logic, applying salary-based and gender-based rules, calculating tax deductions, and exporting results to CSV.



## 

## Key Features



* Dynamic generation of 500 employees
* Unique 4-digit employee IDs
* Salary range: $5000 - $50,000
* Gender assignment
* Tax calculation (10%, rounded to 2 decimal places)
* Employee level assignment:
* A1: Salary > $10,000 and < $20,000
* A5-F: Salary > 7,500 and < 30,000 and Gender = Female
* Robust error handling using 'tryCatch().'
* CSV export using base R

## 

## Requirements



* R version 4.0 or higher
* Jupyter Notebook or JupyterLab with R kernel
* Base R packages only

## 

## How to Run (Jupyter Notebook)



This program was developed and executed using a Jupyter Notebook with an R kernel.

1. Open Jupyter Notebook or JupyterLab.
2. Open the R Notebook file.
3. Select the R kernel.
4. Run all cells sequentially
5. The payroll output will be generated as 'hcc\_payment\_slips.csv'.

## 

## Output



A CSV file named hcc\_payment\_slips.csv containing
structured payroll data.

