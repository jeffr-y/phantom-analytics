# Payroll Processing Program (Python)



This program simulates a payroll system for 500 employees using Python. It dynamically generates employee records, applies business rules for employee classification, calculates payroll deductions, and exports the results to a CSV file.

## 

## Key Features



* Dynamic generation of 500 employees
* Unique 4-digit employee IDs
* Salary range: $5000 - $50,000
* Gender assignment
* Tax calculation (10%, rounded to 2 decimal places)
* Employee level assignment:
* A1: Salary > $10,000 and < $20,000
* A5-F: Salary > 7,500 and < 30,000 and Gender = Female
* Exception handling for data and file errors
* CSV export of payroll results

## 

## Requirements



* Python 3.8 or higher
* Jupyter Notebook or JupyterLab
* Standard libraries: 'random', 'csv.'

## 

## How to Run (Jupyter Notebook)



This program was developed and executed using a Jupyter Notebook.

1. Open Jupyter Notebook or JupyterLab.
2. Open the Python Notebook file.
3. Ensure the Python kernel is selected.
4. Run all cells from top to bottom.
5. The payroll output will be generated as 'payment\_slips.csv'.

## 

## Output



A CSV file named payment\_slips.csv containing:
ID, Name, Gender, Level, Salary, Tax, Net Pay

