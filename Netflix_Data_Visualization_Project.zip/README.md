## **Netflix Movies \& TV Shows**



## **End-to-End Data Cleaning, Data Engineering, Exploratory Data Analysis, and Visualization**



### **Project Overview**



This project provides a full, professional-grade data workflow for analyzing the Netflix Movies \& TV Shows dataset.

It includes automated data ingestion, cleaning, feature engineering, exploratory data analysis (EDA), and visualization. The project is implemented across four structured notebooks ( three in Python, and one in R).

The workflow is modular, reproducible, and designed for analytics, storytelling, and future model-building



### **Business Questions Explored**



This project is structured to answer key analytical and business-driven questions

about Netflix content:



How has Netflix's content library grown over time?

What is the distribution between Movies and TV Shows?

Which genres dominated the platform?

Which countries contributed the most content?

How has content addition changed after 2015?

What audience segments (Family, Teen, Mature) are most represented?

How does movie duration vary across the platform?

What release decade are most common?



These questions guide the data cleaning, feature engineering, and visualization

decisions throughout the project.



### **Repository Structure**



Project/

|

|\_\_\_ Notebook\_01\_Data\_Ingestion.-filename Netflix\_shows\_movies\_analytics\_nb\_1.ipynb 

|

|\_\_\_ Notebook\_02\_Cleaning\_and\_Feature Engineering.-filename Netflix\_shows\_movies\_analytics\_nb\_2.ipynb

|

|\_\_\_\_Notebook\_03\_EDA\_and \_Visualization.-filename Netflix\_shows\_movies\_analytics\_nb\_3.ipynb

|

|\_\_\_\_ Notebook\_04.-filename Netflix\_shows\_movies\_R\_visuals.ipynb

|

|

|\_\_\_\_ data\_raw/

|

|\_\_\_\_ data\_cleaned
|

|\_\_\_\_ Data\_engineered/

|

|\_\_\_\_ Netflix\_Figures/

|

|\_\_\_\_ eda\_summary.json

|

|\_\_\_\_ README.md





#### Notebook 1--Automated Data Ingestion





###### **Purpose**: Fetch, unzip, rename, and store the raw dataset in a structured folder.



###### **Key Tasks**



**Detect downloaded dataset(Zip, CSV, or Excel)**

Unzip and extract files

Rename files to a standardized naming convention

Store in data\_raw/

Validate file integrity (size, extension, encoding)





#### Notebook 2 --Data Cleaning \& Feature Engineering

###### 

###### **Purpose:** Build a professional cleaning pipeline and engineer analytical features.



###### **Steps Included**

1. Import libraries \& Load Raw Data

* &nbsp;	Load raw Excel
* &nbsp;	Inspect structure and missing values



###### **2. Cleaning Pipeline Function**



A reusable function that:

* Fixes encoding issues
* Standardizes column names
* Converts list-like strings to Python lists
* Handles missing values
* Validates primary key(show\_id)
* Normalize date formats
* Extracts duration values
* Ensures consistent data types



###### **3. Run Cleaning Function**



* Apply cleaning pipeline
* Output a single structured summary:

&nbsp;	missing values before/after

&nbsp;	Row/column counts

&nbsp;	Data types

&nbsp;	integrity checks



###### **4. Load Cleaned Data**

* Reload cleaned dataset from data\_cleaned/



###### **5. Professional Feature Engineering**



* Feature include:
* Time-based features (year\_added,month\_added, etc.)
* Content age (content\_age\_when\_added)
* Movie duration extraction
* Genre count, cast count, country count
* Rating grouping (Family, Teen, Mature, Other)
* Release decade
* Recent release flag



###### **6. Single Output Summary After Feature Engineering**



* Sorted missing values
* Data types
* Memory usage
* Feature sanity checks
* Preview of engineered dataset

###### 

###### **7.Save Engineered Dataset**



Stored in:



Netflix\_shows\_movies\_engineered.xlsx





#### **Notebook 3 -- Exploratory Data Analysis (EDA) \& Visualization**





###### Purpose: Analyze the engineered dataset and generate insights + visual storytelling



###### **EDA Metrics Computed**



* **Top genres**
* **Top Countries**
* **Type Distribution(Movies vs TV shows)**
* **Rating distribution**
* **Movie duration summary**
* **Additional metrics as needed**



###### **Structured EDA Summary**



**A dictionary containing** 



**{**

**"rows":....,**

**"columns":..,**

**"type\_distribution":{...}.**

**"top\_genres":{...},**

**"top\_countries":{...},**

**"timestamp":"..."**

**}**



Saved as:

eda\_summary.json



###### **Visualization Section**





Creates Netflix\_Figures/ folder automatically

Generates 14 professional plots, including:



* Movies vs TV Shows distribution
* Top 15 genres
* Top Countries
* Rating distribution
* Content growth overtime
* Release decade trends
* movie duration histogram
* Many more



Each plot is:



Styled with consistent aesthetics

Displayed in notebook

Saved as high-resolution PNG (300dpi



#### **Notebook 4 --- R Visualization Notebook**



###### 

###### **Purpose:** Reproduce or extend visualizations using R(ggplot2).



###### **Includes**



* **Loading engineered dataset**
* **Converting Python-style list strings to R vectors**
* Unnesting genres
* Computing top 15 genres
* Creating aggplot2 bar chart
* Saving the figure to Netflix\_Figures/



This note book is ideal for 

* R Markdown reports
* Shiny dashboards
* Cross-language reproducibility





### **Dependencies**



#### **Python**



* Pandas
* numpy
* seaborn
* matplotlib
* ast
* json
* os



#### **R**



* tidyverse (dplyr, tidyr, ggplot2)
* readxl
* stringr





#### **Folder Outputs**



**data\_raw/**

**Raw downloaded dataset.**



**data\_cleaned/**

Cleaned dataset after pipeline.



data\_engineered/

Feature-engineered dataset.



Netflix\_Figures/

All saved visualizations (PNG)



eda\_summary.json

Machine-readable EDA summary.







#### **Key Insights (Example)**



* Netflix host more movies than TV shows
* Content additions accelerated after 2015
* The United States dominates production
* Drama is the most common genre



#### 

#### **How to Run the Project**

1. Run Notebook 1 to ingest raw data
2. Run Notebook 2 to clean + engineer features
3. Run Note book 3 to perform EDA + generate visualizations
4. Optionally run Notebook 4 for R-based visuals





























































































































































































































































































&nbsp;	









































































































































## 

## Key Features



* Dynamic generation of 500 employees
* Unique 4-digit employee IDs
* Salary range: $5000 - $50,000
* Gender assignment
* Tax calculation (10%, rounded to 2 decimal places)
* Employee level assignment:
* A1: Salary > $10,000 and < $20,000
* A5-F: Salary > 7,500 and < 30,000 and Gender = Female
* Exception handling for data and file errors
* CSV export of payroll results

## 

## Requirements



* Python 3.8 or higher
* Jupyter Notebook or JupyterLab
* Standard libraries: 'random', 'csv.'

## 

## How to Run (Jupyter Notebook)



This program was developed and executed using a Jupyter Notebook.

1. Open Jupyter Notebook or JupyterLab.
2. Open the Python Notebook file.
3. Ensure the Python kernel is selected.
4. Run all cells from top to bottom.
5. The payroll output will be generated as 'payment\_slips.csv'.

## 

## Output



A CSV file named payment\_slips.csv containing:
ID, Name, Gender, Level, Salary, Tax, Net Pay

