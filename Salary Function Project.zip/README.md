# README.md



----- markdown



# **Employee Function Program**

# 

### **Employee Profile Data Processing**

# 

##### **Overview**



1. This project contains Python and R programs to manage employee data stored in CSV and JSON formats. The programs allow you to:
2. Import the provided salary data into your Jupyter notebook Python environment and display the first five rows.
3. Export individual employee profiles from a master Excel/csv dataset.
4. Zip and Save employee profiles in both CSV and JSON formats with automatic time stamping, using the Python zip archive module. Create a README.txt with time stamp for each instance of the program run
5. Unzip the folder containing employee profiles and process with the R program. Then print the head() of each csv and json files in the zip folder, and save the entire file in a folder called Employee profiles unzipped.
6. Handle errors gracefully, ensuring smooth execution even in the case of missing files or permission issues.

## 

#### **Programs Used**



##### **Python Programs**



###### 1a. Import master CSV(Total.csv) into Jupyter notebook using Python environment

###### 1b. Export employee profile and Zip using Python environment

##### 

###### **Purpose:**



Filter employee data from the master CSV(Total.csv)and export individual profiles as CSV and JSON files with a time stamp, and create a zip folder to store the filtered CSV and JSON files.

##### 

###### **Features:**



* Case-insensitive search by employee name
* Saves file in a folder named Employee profile
* Automatically creates the folder if it does not exist.
* Converts strings to NaN to allow for Math and Statistical operations
* Adds a timestamp to filenames to prevent overwriting.
* Zips the folder, creating Employee Profile.zip
* Create a README file with a timestamp for each run instance detailing which file was added to the zip folder for that run instance.
* Graceful error handling for:

 	Missing Master CSV(Total.csv) file

 	Invalid employee name

 	Permission or file write errors



###### **Example Usage:**



**source(SalaryFunction.ipynb)**

**export\_multiple\_employee\_profiles(\["Nathaniel", "Gary", "Pardini", "Chong"])**

###### 

###### **Output:**



CSV file loaded successfully.

&nbsp;       EmployeeName                                        JobTitle  \\

0     NATHANIEL FORD  GENERAL MANAGER-METROPOLITAN TRANSIT AUTHORITY   

1       GARY JIMENEZ                 CAPTAIN III (POLICE DEPARTMENT)   

2     ALBERT PARDINI                 CAPTAIN III (POLICE DEPARTMENT)   

3  CHRISTOPHER CHONG            WIRE ROPE CABLE MAINTENANCE MECHANIC   

4    PATRICK GARDNER    DEPUTY CHIEF OF DEPARTMENT,(FIRE DEPARTMENT)   



&nbsp;    BasePay  OvertimePay   OtherPay  Benefits   TotalPay  TotalPayBenefits  \\

0  167411.18         0.00  400184.25       NaN  567595.43         567595.43   

1  155966.02    245131.88  137811.38       NaN  538909.28         538909.28   

2  212739.13    106088.18   16452.60       NaN  335279.91         335279.91   

3   77916.00     56120.71  198306.90       NaN  332343.61         332343.61   

4  134401.60      9737.00  182234.59       NaN  326373.19         326373.19   



&nbsp;  Year  

0  2011  

1  2011  

2  2011  

3  2011  

4  2011  

Added 'Nathaniel' profile to ZIP.

Added 'Gary' profile to ZIP.

Added 'Pardini' profile to ZIP.

Added 'Chong' profile to ZIP.

All available employee profiles added. ZIP location: C:\\Users\\jeffr\\Employee Profile.zip

##### 

##### **R Program**



###### **2. unzip\_employee\_profile Using the R program**



###### **Purpose:**



**Unzip the folder containing the employee profile (Employee Profile, zip) to a specified folder, read the CSV/JSON file, then display the head()**



###### **Features:**



* Check if the zip file exists
* Creates a folder for unzipped files if it does not exist.
* Converts NaN to Null for proper display of Json file
* Graceful error handling for:

 	Missing Zip file

 	Folder creation issues

 	Unzip failures

Prints both a confirmation message upon successful extraction and firs five rows of the files within the folder

Supports future processing of CSV/JSON files silently



###### **Example Usage:**



**# Run in RStudio or Jupyter Notebook (R Kernel)**

**source(UnzipPipsalaryfunctionfolderinR\&displaydata.ipynb)**



###### **Output:**



Files unzipped successfully to: C:/Users/jeffr/Employee\_Profile\_Unzipped  

---File: Chong\_Profile\_20260208\_093647.csv ---

\# A tibble: 5 × 9

&nbsp; EmployeeName         JobTitle   BasePay OvertimePay OtherPay Benefits TotalPay

&nbsp; <chr>                <chr>        <dbl>       <dbl>    <dbl>    <dbl>    <dbl>

1 CHRISTOPHER CHONG    WIRE ROPE…  77916       56121.  198307.       NA  332344.

2 CHONG NIE            ELECTRONI…  96811.       5814.    9259.       NA  111884.

3 ALEXANDER CHONG      STREET EN…  88258.      18816.     886.       NA  107960.

4 JOSEPH CHONG         TRANSIT O…  66857.      34310.    5206.       NA  106373.

5 SARAVUT CHANBANCHONG ELECTRICA…  77580.      23317.    2790.       NA  103688.

\# ℹ 2 more variables: TotalPayBenefits <dbl>, Year <dbl>



---File: Chong\_Profile\_20260208\_093647.json ---

&nbsp;         EmployeeName                                         JobTitle

1    CHRISTOPHER CHONG             WIRE ROPE CABLE MAINTENANCE MECHANIC

2            CHONG NIE                ELECTRONIC MAINTENANCE TECHNICIAN

3      ALEXANDER CHONG STREET ENVIRONMENTAL SERVICES OPERATIONS SUPERVI

4         JOSEPH CHONG                                 TRANSIT OPERATOR

5 SARAVUT CHANBANCHONG               ELECTRICAL TRANSIT SYSTEM MECHANIC

&nbsp;  BasePay OvertimePay  OtherPay Benefits TotalPay TotalPayBenefits Year

1 77916.00    56120.71 198306.90       NA 332343.6         332343.6 2011

2 96811.20     5813.57   9259.45       NA 111884.2         111884.2 2011

3 88258.18    18815.75    886.36       NA 107960.3         107960.3 2011

4 66857.18    34310.24   5205.54       NA 106373.0         106373.0 2011

5 77580.40    23317.29   2790.17       NA 103687.9         103687.9 2011



#### 

#### **Folder Structure**



Projects/



Total.csv



SalaryFunction.ipynb (Python Kernel)



UnzipPipsalaryfunctionfolderinR\&displaydata.ipynb (R Kernel)



README.md



Employee Profile.zip/   # Python program output (CSV \&JSON files)



Employee Profile Unzipped/   # R program output (unzipped folder)





#### **Requirements**



##### **Python**

* Python 3.8
* Libraries:

 	pandas

 	json

 	os

 	datetime

 	zipfile

 	math

###### Install dependencies:

using Anaconda terminal

conda install pandas

or

conda install -c conda-forge pandas



##### **R**

* **R 4.0+**
* **Libraries**

  **readr**

  **isonlite**

  **dplyr(optional)**

  

  **Create R in via Anaconda Terminal**

  conda create -n r\_env r-base r-essentials -c conda-forge

  

  **Install packages**

  conda install r-readr r-jsonlite r-dplyr -c conda-forge

  

  Notes

* Ensure the master CSV (Total.csv) has a column named Employee Name
* The Python program handles partial or full names (case-insensitive
* R Program can be extended to read and combine all CSV/JSON files after unzipping for analysis

  

  

  #### **How to Run (Jupyter Notebook)**

  

  This program was developed using Jupyter Notebooks.

1. Open Jupyter Notebook or JupyterLab.
2. Select the appropriate kernel (Python or R)
3. Run all cells in the notebook
4. A CSV file ( 'payment\_slips.csv and 'hcc\_payment\_slips.csv') will be generated as output

   ## 

   #### **Learning Outcome**

   

* Control structures ('for', 'if')
* Zipping and unzipping with Python and R, respectively
* Exception handling
* converting strings to NaN
* converting NaN to Null for JSON handling
* Cross-language operations (Python vs R

  ## 

  ## 

