# Shared Utility Function (PCA_utils.py)
# save excel outputs
import os
import pandas as pd

def save_pca_outputs(
    X_pca=None,
    loadings=None,
    feature_contribution=None,
    explained_variance=None,
    cumulative_variance=None,
    output_folder=r"C:\Users\jeffr\principal_component_analysis_project\pca_outputs",
    filename="pca_results.xlsx"
):
    """
    Saves PCA-related outputs to an Excel file with multiple sheets.
    Only saves sheets for objects that are provided (not None).
    
    Parameters:
    - X_pca: PCA-transformed data (numpy array or DataFrame)
    - loadings: PCA loadings DataFrame
    - feature_contribution: Series of reconstructed feature importance
    - explained_variance: array-like of explained variance ratios
    - output_folder: folder to save results
    - filename: Excel file name
    """

    # Create output folder if needed
    os.makedirs(output_folder, exist_ok=True)

    # Build full path
    excel_path = os.path.join(output_folder, filename)

    with pd.ExcelWriter(excel_path) as writer:

        # Save PCA components
        if X_pca is not None:
            if isinstance(X_pca, pd.DataFrame):
                df_pca = X_pca
            else:
                df_pca = pd.DataFrame(
                    X_pca,
                    columns=[f"PC{i+1}" for i in range(X_pca.shape[1])]
                )
            df_pca.to_excel(writer, sheet_name="PCA_Components", index=False)
        
        # Save PCA Loadings
        if loadings is not None:
            loadings.to_excel(writer, sheet_name="PCA_Loadings")
            
        # Save reconstructed feature contributions
        if feature_contribution is not None:
            feature_contribution.to_excel(writer, sheet_name="Feature_Contribution")

        # Save explained variance + cumulative variance
        if explained_variance is not None:
            df_var = pd.DataFrame({
                "PC": [f"PC{i+1}"  for i in range(len(explained_variance))],
                "Explained Variance": explained_variance,
                "Cumulative Variance": cumulative_variance
            })
            df_var.to_excel(writer, sheet_name="Explained_Variance", index=False)

    print(f"PCA results saved to: {excel_path}")

# Save figures
import os
import matplotlib.pyplot as plt

def save_figure(
    fig,
    filename,
    output_folder=r"C:\Users\jeffr\principal_component_analysis_project\pca_outputs",
    dpi=300,
    tight=True
):
    """
    Saves a Matplotlib figure to a specified folder.

    Parameters:
    - fig: Matplotlib figure object (e.g., plt.gcf())
    - filename: Name of the output image file (e.g., 'top10_features.png')
    - output_folder: Folder where the figure will be saved
    - dpi: Image resolution
    - tight: Whether to use bbox_inches='tight' for clean cropping
    """

    # Create folder if needed
    os.makedirs(output_folder, exist_ok=True)

    # Build full path
    fig_path = os.path.join(output_folder, filename)

    # Save figure
    if tight:
        fig.savefig(fig_path, dpi=dpi, bbox_inches='tight')
    else:
        fig.savefig(fig_path, dpi=dpi)

    print(f"Figure saved to: {fig_path}")                    

def save_model_result(
    accuracy=None,
    confusion_matrix=None,
    classification_report=None,
    output_folder=r"C:\Users\jeffr\principal_component_analysis_project\model_outputs",
    filename="model_results.xlsx"
):
    """
    Saves model evaluation results (accuracy, confusion_matrix, classification report)
    into an Excel file with separate sheets.

    Parameters:
    - accuracy: float
    - confusinon_matrix: 2D array or DataFrame
    - output-folder: folder to save results
    - filename: Excel file name
    """
    # Create output folder if needed
    os.makedirs(output_folder, exist_ok=True)

    # Build full path
    excel_path = os.path.join(output_folder, filename)
    
    with pd.ExcelWriter(excel_path) as writer:

        # Save accuracy
        if accuracy is not None:
            pd.DataFrame({"Accuracy": [accuracy]}).to_excel(
                writer, sheet_name="Accuracy", index=False
            )

        # Save confusion matrix
        if confusion_matrix is not None:
            if isinstance(confusion_matrix, pd.DataFrame):
                conf_matrix_df = confusion_matrix
            else:
                conf_matrix_df=pd.DataFrame(confusion_matrix)
            conf_matrix_df.to_excel(writer, sheet_name="Confusion_Matrix", index=False)

        # save classification report
        if classification_report is not None:
            if isinstance(classification_report, pd.DataFrame):
                report_df = classification_report
            else:
                # Convert text report to DataFrame-like structure
                report_df = pd.DataFrame({"Report":classification_report.split("\n")})
            report_df.to_excel(writer, sheet_name="Classification_Report", index=False)

    print(f"Model results saved to: {excel_path}")
            
def save_figure_model(
    fig,
    filename,
    output_folder=r"C:\Users\jeffr\principal_component_analysis_project\model_outputs",
    dpi=300,
    tight=True
):
    """
    Saves a Matplotlib figure to a specified folder.

    Parameters:
    - fig: Matplotlib figure object (e.g., plt.gcf())
    - filename: Name of the output image file (e.g., 'model.png')
    - output_folder: Folder where the figure will be saved
    - dpi: Image resolution
    - tight: Whether to use bbox_inches='tight' for clean cropping
    """

    # Create folder if needed
    os.makedirs(output_folder, exist_ok=True)

    # Build full path
    fig_path = os.path.join(output_folder, filename)

    # Save figure
    if tight:
        fig.savefig(fig_path, dpi=dpi, bbox_inches='tight')
    else:
        fig.savefig(fig_path, dpi=dpi)

    print(f"Figure saved to: {fig_path}")                    

            