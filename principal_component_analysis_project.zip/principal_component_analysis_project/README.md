## **Principal Component Analysis \& Logistic Regression Pipeline**



## **A modular, multi-notebook workflow for PCA, dimensionality reduction, classification, and interpretability.** 



### **Project Overview**



This project demonstrates a complete PCA-driven machine learning workflow using the Breast Cancer Wisconsin dataset from sklearn.datasets.

The workflow is intentionally split across five modular notebooks, each responsible for a specific state of the analysis:

PCA Essential Variables

Dimensionality Reduction (2D PCA)

3\. Logistic Regression on PCA Components

Feature Contribution back-Mapping

Visualization \& Reporting

R Notebook for Visualization



Each notebook saves only the outputs relevant to its stage, ensuring a clean, reproducible, and professional pipeline.



### **Folder Structure**

principal\_component\_analysis\_project/

|

|\_\_\_Notebooks/

|   |

|   |\_\_\_ 1\_pca\_essential\_variables.ipynb

|   |\_\_\_ 2\_pca\_dimentioanlity\_reduction.ipynb

|   |\_\_\_ 3\_Logistic\_regression.ipynb

|   |\_\_\_ 4\_feature\_contribution.ipynb

|   |\_\_\_ 5\_visual5ization.ipynb

|   |\_\_\_ 6\_ R diverging bar chat visualization

|

|

|\_\_\_ pca\_utils.py

|

|

|\_\_\_ pca\_outputs/

|   |

|   |\_\_Pca\_results.xlsx

|

|\_\_\_ model\_outputs/

|   | 

|   |\_\_model\_results.xlsx

|   |\_\_ top10\_features.xlsx

|

|\_\_\_figures/

&nbsp;   |

&nbsp;   |\_\_pca\_explained\_variance.png

&nbsp;   |\_\_2d\_pca\_breast\_cancer\_dataset.png

&nbsp;   |\_\_logreg\_decision\_boundary.png

&nbsp;   |\_\_top10\_feature\_contributions.png

&nbsp;   |\_\_top10\_feature\_contributions\_R.png







### **Notebook Descriptions \& Outputs**

#### 

#### **Notebook 1 PCA Essential Variable** 



##### **Purpose:**

* Standardize data
* Apply PCA
* Extract loadings
* Compute explained \& cumulative variance

###### **Saves:**

* pca\_results.xlsx(loadings, explained variance, cumulative variance)
* Optional PCA figures



#### **Notebook 2: Dimensionality Reduction (2 Components)**

###### **Purpose:**

* reduce dataset to 2 PCs
* Visualize PCA scatter plot

###### **Saves:**

Only figures(e.g., 2d\_pca\_breast\_cancer\_dataset.png

Does Not save PCA outputs as it is already saved in Notebook 1





#### **Notebook 3: Logistic Regression on PCA Components**



###### **Purpose:**

* Train/test split
* Logistic Regression 2D PCA
* Evaluate model performance

###### **Saves:**

* Models\_results.xlsx

&nbsp;	Accuracy

&nbsp;	Confusion Matrix

&nbsp;	Classification Report

* Decision boundary figure

**Does Not save PCA outputs**



#### **Notebook 4: Feature Contribution Back-Mapping**



###### **Purpose:**



* Map logistic regression coefficient back to the original features
* Identify the top 10 contributing features

This file is later used by the R script for enhanced visualization.



###### **Saves:**

* top10\_features.xlsx

**Does not overwrite PCA or model results**



#### **Notebook 5: Visualization Notebook**

###### **Purpose:**

* Produce final plots for reporting
* No new PCA or model computations



###### **Saves:**



* top10\_feature\_contributions.png
* 2d\_pca\_scatted\_plot\_colored\_by\_logistic\_regression.png



#### **Utility Functions (pca\_utils.py)**



**save\_pca\_outputs()**

Saves PCA-related output into pca\_results.xlsx



**save\_model\_result()**

Saves model evaluation metrics into model\_results.xlsx



save\_figure()

Saves Matplotlib figures to the appropriate folder.



save\_figure\_model()

Saves Matplotlib figures to the appropriate folder.



All utilities automatically create folders if they do not exist.



#### **Notebook 6: R Visualization Diverging Bar chart**



To complement the Python workflow, R script is used to reproduce the top10 contributors visuals.



#### **Key Insights from the Project**



* PCA reveals the most influential features in the breast cancer dataset.
* Two principal components capture a large portion of the variance.
* Logistic Regression on PCA-reduced data achieves high accuracy
* Feature back-mapping identifies the original variables driving classification decisions



#### **Final Notes**



**This Modular design ensures:**



* No accidental overwriting
* Clean separation of PCA, modeling, and interpretability
* Reproducibility across all notebooks
* Professional, presentation-ready outputs



**The Project supports**



* Python-based PCA and modeling
* Python-based figure generation
* R-based interpretability visualization
* Clean separation of outputs across folders
* A fully reproducible, multi-language analytics workflow









































































































































































































 











































































































































