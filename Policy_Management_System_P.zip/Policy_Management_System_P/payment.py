# Policy_Management_System/ Folder Build up
# Payment.py = Payment class + PaymentManager class

#----------------
# 3. payment.py
#---------------
import math
from datetime import datetime, timedelta

#-----------------------------------
# Create the Payment (invoice) Class
#-----------------------------------
class Payment:
    def __init__(self, payment_id, holder_id, product_id, amount, due_date):
        try:
            self.amount = float(amount)
        except ValueError:
            self.amount = math.nan
            
        self.payment_id = payment_id
        self.holder_id = holder_id
        self.product_id = product_id

        # Ensure due_date is datetime
        if isinstance(due_date, str):
            self.due_date = datetime.fromisoformat(due_date)
        else:
            self.due_date = due_date 
            
        self.payment_date = None
        self.paid = False
        self.penalty = 0.0   
        self.grace_period_days = 5    # 5-day grace period configurable

    # ------------------
    # Business Logic
    # ------------------
    def mark_paid(self):
        if not self.paid:
            self.paid = True
            self.payment_date = datetime.now()
    
    # Check if the payment is overdue, considering the grace period
    def is_overdue(self):
        if self.paid:
            return False
            
        overdue_date = self.due_date + timedelta(days=self.grace_period_days)
        return datetime.now() > overdue_date

    # Apply a flat penalty if overdue 
    def apply_penalty(self, flat_penalty=10.0):
        if self.is_overdue() and self.penalty == 0.0:
            self.penalty = flat_penalty
            
    # convert to dict for JSON/CSV, ensure Penalty is applied before exporting, and export
    def to_dict(self):
        self.apply_penalty()
        return {
            "payment_id": self.payment_id,
            "holder_id": self.holder_id,
            "product_id": self.product_id,
            "amount": None if math.isnan(self.amount) else self.amount,
            "paid": self.paid,
            "penalty": self.penalty,
            "grace_period_days": self.grace_period_days,
            "due_date": self.due_date.isoformat(),
            "payment_date": None if not self.payment_date else self.payment_date.isoformat(),
            "overdue": self.is_overdue()
        }
            
#--------------------------
# PaymentManagement Class (Billing Controller)
# --------------------------
class PaymentManager:
    def __init__(self, policy_manager, product_manager):
        self.policy_manager = policy_manager
        self.product_manager = product_manager
        self.payments = []
        self._next_payment_id = 201 # Stare at 201
        
    #-----------------------------------
    # Create Invoice (Unpaid)
    #-----------------------------------
    def create_payments_for_holder(self, holder_id, product_ids):
        holder = self.policy_manager.policyholders.get(holder_id)
        if not holder:
            raise Exception("Policyholder does not exist")
        if not holder.active:
            raise Exception("Policyholder is suspended")

        created = [] 
        for pid in product_ids:
            product = self.product_manager.products.get(pid)
            if not product:
                raise Exception(f"Product {pid} does not exist")
            if not product.active:
                raise Exception(f"Product {pid} is suspended")

            payment = Payment(
                payment_id=self._next_payment_id, 
                holder_id=holder_id,
                product_id=pid, 
                amount=product.premium,
                due_date=datetime.now() + timedelta(days=5)
            )
            self.payments.append(payment)
            created.append(payment)
            self._next_payment_id += 1

        return created

    #---------------------------------------------
    # UI Parsing Wrapper
    #---------------------------------------------
    def create_payments_from_string(self, holder_id, product_ids_string):
        if not product_ids_string:
            raise ValueError("No Product IDs provided")
        try:
            ids = [int(x.strip()) for x in product_ids_string.split(",")]
        except ValueError:
            raise ValueError("Product IDs must be integers separated by commas")
        return self.create_payments_for_holder(holder_id, ids)
            
    #------------------------------
    # Mark payment as Paid
    # ------------------------------
    def mark_payment_paid(self, payment_id):
        payment = self.get_payment(payment_id)
        if not payment:
            raise Exception("Payment not found")
        payment.mark_paid()

    #---------------------------
    # Helper: Get Payment
    #--------------------------
    def get_payment(self, payment_id):
        for payment in self.payments:
            if payment.payment_id == payment_id:
                return payment
        return None
            

    #-----------------------------------------
    # Apply penalties for all overdue payments
    #-----------------------------------------
    def apply_penalties(self, flat_penalty=10.0):
        for payment in self.payments:
            payment.apply_penalty(flat_penalty)
                        
        
        
