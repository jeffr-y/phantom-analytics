# Policy_Management_System/ Folder Build up
# display_utils.py 

#----------------------
# 4. display_utils.py
#----------------------

from datetime import datetime, timedelta


def display_accounts(policy_manager, product_manager, payment_manager):
    """
    Display all policyholders, their products, payments,
    overdue status, and penalties.
    """
    
    for holder in policy_manager.policyholders.values():
        print("\n---------------------------")
        print(f"Policyholder: {holder.name}")
        print(f"Status: {'Active' if holder.active else 'Suspended'}")

        # Filter payments for each holder
        holder_payments = [
            p for p in payment_manager.payments 
            if p.holder_id == holder.holder_id
        ]

        if not holder_payments:
            print("No payments found for this policyholder.")
            continue

        for p in holder_payments:
            # Ensure penalty and overdue status are current
            p.apply_penalty()   # penalty applied automatically
            overdue = p.is_overdue()
            
            product = product_manager.products.get(p.product_id)
            product_name = product.name if product else "Unknown Product"

            print(
                f"Product: {product_name} | "
                f"Amount: {p.amount} | "
                f"Paid: {p.paid} | "
                f"Overdue: {'Yes' if overdue else 'No'} | "
                f"Penalty: {p.penalty}"
            )
            

#--------------------------------
# Reminder System
#-------------------------------
def send_payment_reminders(payment_manager, reminder_window_days=2):
    """
    Send reminders for unpaid payments:
    - Reminder if due within reminder_window_days
    - Alert if overdue
    """

    
    today = datetime.now()
    
    for p in payment_manager.payments:

        if p.paid:
            continue
        
        due_with_grace = p.due_date + timedelta(days=p.grace_period_days)
        
        # Apply penalty if necessary
        p.apply_penalty()

        # if overdue
        if p.is_overdue():
            print(
                f"OVERDUE: Payment {p.payment_id} "
                f"for holder {p.holder_id} | "
                f"Penalty: {p.penalty}"
            )

        # if approaching due date
        elif 0 <= (p.due_date - today).days <= reminder_window_days:
            print(
                f"Reminder: Payment {p.payment_id}"
                f"for holder {p.holder_id}"
                f"is due on {p.due_date.date()}"
                f"(Grace ends: {due_with_grace.date()})"
            )
                
    