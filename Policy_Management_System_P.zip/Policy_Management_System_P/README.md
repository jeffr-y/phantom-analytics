# Policy Management System (Python)



## Overview



This Policy Management System is a modular billing and policy management application built in Python, using OOP (Object Oriented Programming) Principles, and an interactive Jupyter Notebook UI.



The system allows administrators to:



* Register policyholders
* Suspend/Activate (manager) policyholders
* Add insurance products
* Suspend/Activate (manage) insurance products
* Create payment invoices
* Make payment (Mark selected invoices as paid)
* Apply penalties dynamically for overdue payments
* Send payment reminders
* Display all accounts in a live dashboard
* Export payment records to CSV \& JSON
* Package the full system as a ZIP archive
* Refresh Invoices Table



The design follows encapsulation, separation of concerns, and clean architecture principles\\

## 

## System Architecture

The project follows a layered structure:



Policy\_Management\_System/

|

|\_\_\_\_ policyholder.py

|\_\_\_\_ product.py

|\_\_\_\_ payment.py

|\_\_\_\_ display\_utils.py

|\_\_\_\_ export\_utils.py

|\_\_\_\_ notebook.ipynb

|\_\_\_\_ README.md

* unzip program using R program



## Core Components



### File		Responsibility

Policyholder.py			Manages policyholder registration and status

product.py			Manages product creation and activation/suspension

payment.py			Handles invoice creation, payments, and penalties

display\_utils.py		Accounts Display logic

export\_utils.py			Handles data export operations

Notebook.ipynb			UI layer using  ipywidgets



## Payment System Design



The payment system is built around two core classes:



### Payment



Represents a single invoice.



##### Attributes:

* payment\_id
* holder\_id
* product\_id
* amount
* due\_date
* payment\_date
* paid
* penalty
* grace\_period\_days



##### Business Logic:

* mark\_paid()
* is\_overdue()
* apply\_penalty()
* to\_dict() (used for export and dynamic display)



### PaymentManager



Acts as a billing controller.



##### Responsibilities:



* create invoices
* Mark selected invoices as paid.
* Apply penalties
* Send reminders
* Export payment data



###### Encapsulation is strictly maintained:



The UI never directly modifies internal lists.



### Complete Payment Lifecycle



#### Create Payment Invoice



Creates unpaid invoice for selected products.

* input: Holder ID + Product IDs
* Output: Unpaid invoices created
* No penalties applied at creation



#### Make Payment (Selected Invoices Only)

Mark's specific invoices as paid.

* Input: Selected payment IDs
* Only those invoices are marked as paid
* On-time payments never receive penalties
* Overdue payments will have penalties applied



#### Apply Penalties



Applies a flat penalty to:

* Unpaid
* Overdue
* Not previously penalized invoices

Penalties are dynamic and also applied automatically during display/export.



#### Send Payment Reminders



Scans for:



* unpaid
* Overdue invoices



Generated reminder messages per policyholder.



#### Dynamic Payment Table



The dashboard includes a live HTML table showing:

* payment ID
* Holder ID
* Product ID
* Amount
* Paid Status
* Overdue Status
* Penalty

The table updates dynamically and allows users to identify which invoices to mark as paid.



#### Export Data

Exports all payments to JSON and CSV using:



Payment.to\_dict()



Export includes:

* payment status
* penalty
* overdue flag
* dates (ISO format)



#### Business Rules Implemented

* 5-day grace period before overdue
* Flat penalty applied only once
* Paid invoices are never marked overdue
* Penalty never applied to already paid invoices
* UI does not access the internal data structure directly
* Encapsulation preserved throughout



#### Design Principles Used



* ##### Encapsulation



1. All business logic is inside classes.
2. The UI only calls public methods.



* ##### Separation of Concerns

1. UI handles input/output
2. Payment Manager handles business controls
3. Payment class handles invoice logic



* ##### Defensive Programming

1. Input validations for IDs
2. Graceful handling of missing payments
3. safe error Wrapping





### Example Workflow



1. Register Policyholder
2. Add products
3. Create invoices for selected products
4. View dynamic invoice table
5. Mark selected invoices as paid
6. Apply penalties to overdue unpaid invoices
7. Send reminders
8. Export payment records



### Future Improvements (Optional Enhancements)



Checkbox selection instead of manual ID entry

Automatic daily penalty scheduler

Email integration with reminders

Database persistence instead of in-memory lists

Payment history tracking



### Final Outcome

The Policy Payment System is a  fully functional billing lifecycle application demonstrating:



* Object-Oriented Programming
* Clean Architecture
* Dynamic business rules
* UI-to-service separation
* Real-world invoice and  penalty handling



It is a foundation for a production billing system.





## How to Run (Jupyter Notebook)



This program has several .py files; the app is only executable via the .ipynb file from your Jupyter notebook environment. The Zip file can be unzipped using the R kernel, also on a Jupyter notebook.

1. Ensure all the files are saved in the same folder
2. Open Jupyter Notebook or JupyterLab / open the file notebook.ipynb
3. Run all 8 cells sequentially staring from cell 1
4. Then, upon running the last cell, the app opens the UI for your operations
5. Open the R Notebook file.
6. 6\. Select the R kernel. Before running this program, ensure you have finished your business on the app and exported your data, as well as zipped the system.

## 

