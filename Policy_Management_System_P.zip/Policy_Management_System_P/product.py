# Policy_Management_System/ Folder Build up
# Product.py = Product class + Productmanager class

# 2. product.py
# Create the product class 
import math

#--------------------------------
# product class
#--------------------------------

class Product:
    def __init__(self, product_id, name, premium):
        try:
            self.premium = float(premium)
        except ValueError:
            self.premium = math.nan
            
        self.product_id = product_id
        self.name = name
        self.active = True

    def suspend(self):
        self.active = False

    def activate(self):
        self.active = True

    def to_dict(self):
        return {
            "product_id": self.product_id,
            "name": self.name,
            "premium": None if math.isnan(self.premium) else self.premium,
            "active": self.active
        }

#------------------------------
# ProductManager  class
#------------------------------
class ProductManager:
    def __init__(self):
        self.products = {}

    def create_product(self, product_id, name, premium):
        if product_id in self.products:
            raise Exception("Product already exists")
        self.products[product_id] = Product(product_id, name, premium)
        return self.products[product_id]
      
    def get_product(self, product_id):
        if product_id not in self.products:
            raise KeyError(f"Product {product_id} not fond")
        return self.products[product_id]


    def suspend_product(self, product_id):
        product = self.products.get(product_id)
        if not product:
            raise ValueError("Product not found")
        product.suspend()
        
    def activate_product(self, product_id):
        product = self.products.get(product_id)
        if not product:
            raise ValueError("Product not found")
        product.activate()
        
  
        
    


                           