# Policy_Management_System/ Folder Build up
# Policyholder.py = PolicyHolder + PolicyManager

# 1. Policyholder.py
import math

# Create the policyholder class 
class PolicyHolder:
    def __init__(self, holder_id, name, age):
        try:
            self.age = float(age)
        except ValueError:
            self.age = math.nan
            
        self.holder_id = holder_id
        self.name = name
        self.active = True

    def suspend(self):
        self.active = False

    def activate(self):
        self.active = True

    def to_dict(self):
        return {
            "holder_id": self.holder_id,
            "name": self.name,
            "age": None if math.isnan(self.age) else self.age,
            "active": self.active
        }

# Create the PlolicyManager 
# Policy management class
class PolicyManager:
    def __init__(self):
        self.policyholders = {}

# Implement methods to register, suspend, and reactivate policyholders
    def register_policyholder(self, holder_id, name, age):
        if holder_id in self.policyholders:
            raise Exception("Policyholder already exists")
        self.policyholders[holder_id] = PolicyHolder(holder_id, name, age)
        
    def suspend_policyholder(self, holder_id):
        if holder_id not in self.policyholders:
            raise KeyError("Policyholder not found")
            
        self.policyholders[holder_id].suspend()
            
    def activate_policyholder(self, holder_id):
        if holder_id not in self.policyholders:
            raise KeyError("Policyholder not found")
            
        self.policyholders[holder_id].activate()
            