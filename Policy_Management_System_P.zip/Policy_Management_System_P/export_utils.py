# Policy_Management_System/ Folder Build up
#----------------------
# 5. export_utils.py
#----------------------
import os
import json
import csv
from datetime import datetime
import zipfile

#-----------------------
# README Utility
#-----------------------
def write_timestamped_readme(folder):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    readme_path = os.path.join(folder, f"README_{timestamp}.txt")
    
    with open(readme_path, "w") as f:
        f.write(
            "Policy Management System - User Manual\n"
            f"Generated on: {datetime.now()}\n\n"
            "Contents:\n"
            "- Timestamped JSON export\n"
            "- Unified CSV export\n"
            "- Policyholders, Products, Payments\n"
            "- Payments include penalty, overdue status, and grace_period_days\n"
            "- Ready for API / Storage use\n"
        )
    return readme_path

#----------------------
# Unified CSV Export
#----------------------
def export_unified_csv(policy_manager, product_manager, payment_manager, folder):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_file = os.path.join(folder, f"policy_management_{timestamp}.csv")

    with open(csv_file, "w", newline="") as f:
        writer = csv.writer(f)

        writer.writerow([
            "record_type", "id", "name",
            "related_id", "amount",
            "active", "paid", "penalty", 
            "overdue", "grace_period_days",
            "timestamp"
        ])

        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Policyholders
        for h in policy_manager.policyholders.values():
            writer.writerow([
                "POLICYHOLDER",
                h.holder_id,
                h.name,
                "",
                "",
                h.active,
                "",
                "",
                "",
                ts
            ])

        # Products
        for p in product_manager.products.values():
            writer.writerow([
                "PRODUCT",
                p.product_id,
                p.name,
                "",
                p.premium, 
                p.active,
                "",
                "",
                "",
                ts
            ])

        # Payments
        for pay in payment_manager.payments:
            data = pay.to_dict()
            
            writer.writerow([
                "PAYMENT",
                data["payment_id"],
                "",
                f"{data['holder_id']}|{data['product_id']}",
                data["amount"], 
                data["paid"],
                data["penalty"],
                data["overdue"],
                data["grace_period_days"],
                ts
            ])
    
    return csv_file

#----------------------------
# Extended Export (JSON + CSV + README)
#---------------------------
def export_all_extended(pm, prodm, paym):
    folder = "Policy_Management_System"
    os.makedirs(folder, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    # JSON export
    json_file = os.path.join(folder, f"policy_management_{timestamp}.json")

    with open(json_file, "w") as f:
        json.dump({
            "policyholders": [h.to_dict() for h in pm.policyholders.values()],
            "products": [p.to_dict() for p in prodm.products.values()],
            "payments": [p.to_dict() for p in paym.payments]
        }, f, indent=4)

    # CSV export
    csv_file = export_unified_csv(pm, prodm, paym, folder)

    # README
    readme_file = write_timestamped_readme(folder)

    print("Extended export completed")
    print(f"- JSON: {json_file}")
    print(f"- CSV: {csv_file}")
    print(f"- README: {readme_file}")

#-----------------------
# ZIP Utility
#-----------------------
def zip_policy_management_system(folder="Policy_Management_System"):
    zip_name = f"{folder}.zip"

    with zipfile.ZipFile(zip_name, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk(folder):
            for file in files:
                full_path = os.path.join(root, file)
                zipf.write(full_path, arcname=os.path.relpath(full_path, folder))
                
    print(f"Folder zipped successfully: {zip_name}")
        
    

    
            
            
                